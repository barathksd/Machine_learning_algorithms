#!/usr/bin/env bash
jupyter notebook --no-browser --allow-root --ip 0.0.0.0

